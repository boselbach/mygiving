(function() {
    'use strict';

    angular.module('mygiving.controller.survey', [
        'mygiving.resources.survey'
    ])
    .controller('SurveyCtrl', ['$scope', function($scope) {

    }]);
})();
