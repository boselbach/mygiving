(function() {
    'use strict';

    angular.module('mygiving.resources.survey', [])
    .factory('SurveyService'[function() {
        return {

        };
    }]);
})();
