(function() {
    'use strict';

    angular.module('mygiving.controller.index', [])
    .controller('IndexCtrl', ['$scope', function($scope) {
        
    }]);
})();
