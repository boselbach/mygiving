(function() {
    'use strict';

    angular.module('mygiving.controller.navigation', [])
    .controller('NavigationCtrl', ['$scope', function($scope) {
        $scope.menu = ['home', 'survey', 'organisations', 'portfolio'];
    }]);
})();
