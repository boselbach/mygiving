(function() {
    'use strict';

    angular.module('mygiving.services.organisations', [])
    .factory('OrganisationsService', ['$http', '$q', function($http, $q) {
        var selected = [];

        var select = function(organisation) {

        };

        var getAll = function() {
            var defer = $q.defer();

            $http.get('organisations.json?callback=JSON_CALLBACK')
            .success(function(response) {
                defer.resolve(response);
            });

            return defer.promise;
        };

        var getBySlug = function(slug) {

        };

        return {
            getAll: getAll,
            getBySlug: getBySlug
        };
    }]);
})();
