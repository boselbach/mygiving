(function() {
    'use strict';

    angular.module('mygiving.controller.organisation', [
        'mygiving.services.organisations',
        'mygiving.directive.card'
    ])
    .controller('OrganisationCtrl', ['$scope', 'OrganisationsService', function($scope, OrganisationsService) {
        $scope.portfolio = [];

        OrganisationsService.getAll()
        .then(function(data) {
            $scope.organisations = data;
        });

        $scope.setActice = function(index) {
            $scope.activeOrganisation = $scope.organisations[index];
        };

        $scope.add = function() {
            var index = angular.element('.active').attr('index');
            $scope.organisations[index].selected = true;
        };

        $scope.remove = function() {
            var index = angular.element('.active').attr('index');
            $scope.organisations[index].selected = false;
        };
    }]);
})();
