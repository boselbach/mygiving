(function() {
    'use strict';

    angular.module('mygiving.controller.organisation.single', [
        'mygiving.services.organisations'
    ])
    .controller('SingleOrganisationCtrl', ['$scope', 'OrganisationsService', function($scope, OrganisationsService) {
        // OrganisationsService.getBySlug()
        // .then(function(data) {
        //     $scope.organisations = data;
        // });
    }]);
})();
