// (function() {
//     'use strict';
//
//     angular.module('mygiving.services.organisations', [])
//     .factory('PortfolioService', [function() {
//
//         var save = function() {
//
//         };
//
//         var get = function() {
//
//         };
//
//         return {
//             save: save,
//             get: get
//         };
//     }]);
// })();
