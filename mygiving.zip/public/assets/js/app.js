(function() {
    'use strict';

    angular.module('mygiving', [
        'ngRoute',
        'mygiving.controller.navigation',
        'mygiving.controller.index',
        'mygiving.controller.survey',
        'mygiving.controller.organisation',
        'mygiving.controller.organisation.single'
    ])
    .run(['$rootScope', '$templateCache', function($rootScope, $templateCache) {
        $rootScope.$on('$viewContentLoaded', function() {
          $templateCache.removeAll();
       });
    }])
    .config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
        $routeProvider
          .when('/', {
            templateUrl: 'views/home.html',
            controller: 'IndexCtrl'
          })
          .when('/survey', {
            templateUrl: 'views/survey.html',
            controller: 'SurveyCtrl'
          })
          .when('/organisations', {
            templateUrl: 'views/organisations.html',
            controller: 'OrganisationCtrl'
          })
          .when('/organisations/:slug', {
            templateUrl: 'views/organisation.html',
            controller: 'SingleOrganisationCtrl'
          })
          .otherwise({
            redirectTo: '/'
          });
    }]);

    angular.element('document').ready(function() {
        angular.bootstrap(document, ['mygiving']);
    });
})();

(function() {
    'use strict';

    angular.module('mygiving.filters.slygify', [])
    .filter('slugify', [function() {
        return function(text) {
            return text.toLowerCase().replace(/[^\w ]+/g,'').replace(/ +/g,'-');
        };
    }]);
})();

(function() {
    'use strict';

    angular.module('mygiving.services.organisations', [])
    .factory('OrganisationsService', ['$http', '$q', function($http, $q) {
        var selected = [];

        var select = function(organisation) {

        };

        var getAll = function() {
            var defer = $q.defer();

            $http.get('organisations.json?callback=JSON_CALLBACK')
            .success(function(response) {
                defer.resolve(response);
            });

            return defer.promise;
        };

        var getBySlug = function(slug) {

        };

        return {
            getAll: getAll,
            getBySlug: getBySlug
        };
    }]);
})();

// (function() {
//     'use strict';
//
//     angular.module('mygiving.services.organisations', [])
//     .factory('PortfolioService', [function() {
//
//         var save = function() {
//
//         };
//
//         var get = function() {
//
//         };
//
//         return {
//             save: save,
//             get: get
//         };
//     }]);
// })();

(function() {
    'use strict';

    angular.module('mygiving.directive.card', [])
    .directive('card', [function() {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {

                element.on('click', function() {
                    var cards = angular.element('.cards li');

                    cards.removeClass('active');
                    element.addClass('active');
                });
            }
        };
    }]);
})();

(function() {
    'use strict';

    angular.module('mygiving.controller.index', [])
    .controller('IndexCtrl', ['$scope', function($scope) {
        
    }]);
})();

(function() {
    'use strict';

    angular.module('mygiving.controller.navigation', [])
    .controller('NavigationCtrl', ['$scope', function($scope) {
        $scope.menu = ['home', 'survey', 'organisations', 'portfolio'];
    }]);
})();

(function() {
    'use strict';

    angular.module('mygiving.controller.organisation', [
        'mygiving.services.organisations',
        'mygiving.directive.card'
    ])
    .controller('OrganisationCtrl', ['$scope', 'OrganisationsService', function($scope, OrganisationsService) {
        $scope.portfolio = [];

        OrganisationsService.getAll()
        .then(function(data) {
            $scope.organisations = data;
        });

        $scope.setActice = function(index) {
            $scope.activeOrganisation = $scope.organisations[index];
        };

        $scope.add = function() {
            var index = angular.element('.active').attr('index');
            $scope.organisations[index].selected = true;
        };

        $scope.remove = function() {
            var index = angular.element('.active').attr('index');
            $scope.organisations[index].selected = false;
        };
    }]);
})();

(function() {
    'use strict';

    angular.module('mygiving.controller.organisation.single', [
        'mygiving.services.organisations'
    ])
    .controller('SingleOrganisationCtrl', ['$scope', 'OrganisationsService', function($scope, OrganisationsService) {
        // OrganisationsService.getBySlug()
        // .then(function(data) {
        //     $scope.organisations = data;
        // });
    }]);
})();

(function() {
    'use strict';

    angular.module('mygiving.controller.survey', [
        'mygiving.resources.survey'
    ])
    .controller('SurveyCtrl', ['$scope', function($scope) {

    }]);
})();

(function() {
    'use strict';

    angular.module('mygiving.resources.survey', [])
    .factory('SurveyService'[function() {
        return {

        };
    }]);
})();
